# GraphOps AI — 2–3 minute demo video script

**Before recording:** Install and run the app (`streamlit run app.py`). Use the included synthetic sample data. Record your screen with OBS, Windows Snipping Tool screen recording, or another recorder. Keep the browser zoom at 90–100%.

**0:00–0:20 — Introduction**
“Hello, this is GraphOps AI, our cybersecurity prototype for graph-based threat hunting and blast-radius analysis in a Security Operations Center.”

**0:20–0:45 — Dashboard**
“GraphOps converts security event records into a directed graph. These KPI cards show the number of entities, relationships, elevated-risk entities and events analysed.”

**0:45–1:15 — Threat graph and findings**
“Each node represents an entity such as a user, laptop, server or service. The colours represent transparent heuristic risk levels. The findings table explains why an entity was flagged, so an analyst can review the evidence.”

**1:15–1:50 — Blast-radius analysis**
“I select user.alex as the starting entity. The application calculates downstream entities reachable through the observed relationships. This helps an analyst explore a possible impact path; it does not claim that every reachable system is compromised.”

**1:50–2:15 — Custom data and export**
“We can upload a CSV using the documented schema and export the findings for further review.”

**2:15–2:30 — Close**
“This is a hackathon proof of concept using synthetic data and rule-based scoring. The next step would be integration with approved SIEM and endpoint telemetry, plus analyst validation and production-grade access controls. Thank you.”

## Recording checklist
- Show the dashboard and all KPI cards.
- Show the graph and findings table.
- Demonstrate the blast-radius selector.
- Export the findings CSV.
- Avoid showing personal accounts, private files, credentials or real security logs.
