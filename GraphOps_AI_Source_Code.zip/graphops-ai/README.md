# GraphOps AI — HackFront India prototype

GraphOps AI demonstrates graph-based threat hunting and blast-radius analysis for a Security Operations Center (SOC).

## What it does
- Converts event records into a directed relationship graph of users, hosts, servers and services.
- Applies transparent baseline heuristics to flag entities connected to risky event types, high-severity events or unusually high connection counts.
- Calculates downstream reachable entities from a selected starting point to illustrate potential blast radius.
- Displays a graph, findings table and CSV export.

> **Important:** This is a hackathon demonstration using synthetic data and explainable rules. It is not a trained AI model, a production SIEM, or a substitute for analyst validation. Do not connect it to live infrastructure without security review, access controls, testing and appropriate approvals.

## Run locally
1. Install Python 3.10 or newer.
2. Extract this ZIP and open a terminal in the project folder.
3. Create and activate a virtual environment:
   - Windows: `py -m venv .venv` then `.venv\\Scripts\\activate`
   - macOS/Linux: `python3 -m venv .venv` then `source .venv/bin/activate`
4. Install dependencies: `pip install -r requirements.txt`
5. Launch: `streamlit run app.py`
6. Open the local URL printed in the terminal (usually `http://localhost:8501`).

## Input CSV format
Required columns:
- `source`: originating entity (user, device, server, IP, service)
- `target`: destination entity
- `event_type`: event label, e.g. login, lateral_movement, privilege_escalation
- `timestamp`: event time (ISO 8601 recommended)
- `severity`: integer from 1 (low) to 5 (critical)

A synthetic example is included at `data/sample_events.csv`.

## Demo walkthrough
1. Start the app with the sample dataset.
2. Point out the KPI cards (entities, relationships, high-risk entities, events).
3. Explain graph edges as observed interactions between entities.
4. Show red/amber/green risk colours and the reasons in the findings table.
5. Select `user.alex` in Blast-radius analysis; discuss the downstream entities reachable in the graph.
6. Upload a different CSV using the same schema and show how the graph changes.
7. Export the findings CSV.

## Repository structure
```
graphops-ai/
├── app.py
├── requirements.txt
├── README.md
├── data/
│   └── sample_events.csv
└── tests/
    └── test_logic.py
```

## Suggested GitHub publication
Create a **public** repository named `graphops-ai`, then upload the contents of this folder (not the ZIP wrapper). Add the README and sample CSV. Never upload real credentials, API keys, customer logs or sensitive production data.

## Limitations and next steps
- Current scoring is rule-based and deliberately explainable.
- Graph relationships are inferred from event rows; no live integrations are included.
- Blast radius is directed reachability, not proof of compromise.
- Next steps: integrate approved SIEM/EDR telemetry, add identity and asset context, time-window analysis, analyst feedback, role-based access, audit logging, and validated anomaly detection.
