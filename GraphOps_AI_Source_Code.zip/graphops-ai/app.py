import streamlit as st
import pandas as pd
import networkx as nx
import plotly.graph_objects as go
from pathlib import Path

st.set_page_config(page_title="GraphOps AI", page_icon="🛡️", layout="wide")

DEFAULT_CSV = Path(__file__).parent / "data" / "sample_events.csv"

@st.cache_data
def load_events(uploaded_file=None):
    if uploaded_file is not None:
        df = pd.read_csv(uploaded_file)
    else:
        df = pd.read_csv(DEFAULT_CSV)
    required = {"source", "target", "event_type", "timestamp", "severity"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"CSV is missing columns: {', '.join(sorted(missing))}")
    df["severity"] = pd.to_numeric(df["severity"], errors="coerce").fillna(1).clip(1, 5).astype(int)
    return df

def build_graph(df):
    graph = nx.DiGraph()
    for _, row in df.iterrows():
        graph.add_edge(
            str(row["source"]), str(row["target"]),
            event_type=str(row["event_type"]),
            timestamp=str(row["timestamp"]),
            severity=int(row["severity"])
        )
    return graph

def detect_suspicious_nodes(graph, df):
    # Transparent baseline heuristics for a hackathon prototype—not a trained ML model.
    in_degree = dict(graph.in_degree())
    out_degree = dict(graph.out_degree())
    scores = {}
    for node in graph.nodes:
        score = 0
        reasons = []
        if out_degree.get(node, 0) >= 3:
            score += 2; reasons.append("High outbound connections")
        if in_degree.get(node, 0) >= 3:
            score += 1; reasons.append("High inbound connections")
        related = df[(df.source.astype(str) == node) | (df.target.astype(str) == node)]
        if (related.severity >= 4).any():
            score += 2; reasons.append("Linked to high-severity event")
        if related.event_type.astype(str).str.lower().str.contains("lateral|privilege|exfil|malware", regex=True).any():
            score += 2; reasons.append("Risky event category")
        scores[node] = {"score": score, "reasons": reasons or ["No rule triggered"]}
    return scores

def blast_radius(graph, start):
    # Downstream nodes reachable from the selected identity/host.
    return sorted(nx.descendants(graph, start))

def graph_figure(graph, scores, focus=None):
    pos = nx.spring_layout(graph, seed=7, k=0.9)
    edge_x, edge_y = [], []
    for u, v in graph.edges():
        x0, y0 = pos[u]; x1, y1 = pos[v]
        edge_x += [x0, x1, None]; edge_y += [y0, y1, None]
    edge_trace = go.Scatter(x=edge_x, y=edge_y, mode="lines",
        line=dict(width=1, color="#94a3b8"), hoverinfo="none")
    node_x, node_y, colors, sizes, labels, hover = [], [], [], [], [], []
    for node in graph.nodes():
        x, y = pos[node]
        score = scores[node]["score"]
        node_x.append(x); node_y.append(y)
        colors.append("#ef4444" if score >= 4 else ("#f59e0b" if score >= 2 else "#22c55e"))
        sizes.append(22 if node == focus else 15)
        labels.append(node)
        hover.append(f"{node}<br>Risk score: {score}<br>" + "<br>".join(scores[node]["reasons"]))
    node_trace = go.Scatter(x=node_x, y=node_y, mode="markers+text",
        text=labels, textposition="top center", hovertext=hover, hoverinfo="text",
        marker=dict(size=sizes, color=colors, line=dict(width=1, color="white")))
    fig = go.Figure(data=[edge_trace, node_trace])
    fig.update_layout(height=560, margin=dict(l=10,r=10,t=20,b=10),
        showlegend=False, paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)", xaxis=dict(visible=False), yaxis=dict(visible=False))
    return fig

st.title("🛡️ GraphOps AI")
st.caption("Graph analytics for proactive threat hunting and blast-radius containment")
st.info("Prototype note: this demo uses explainable graph heuristics and synthetic sample events. It is not a production security product or a trained AI detector.")

with st.sidebar:
    st.header("Data source")
    uploaded = st.file_uploader("Upload event CSV", type=["csv"])
    st.markdown("**Expected columns:** `source, target, event_type, timestamp, severity`")
    st.markdown("---")
    st.caption("Sample dataset is synthetic and contains no real personal or security data.")

try:
    events = load_events(uploaded)
    G = build_graph(events)
    scores = detect_suspicious_nodes(G, events)
except Exception as exc:
    st.error(f"Could not load data: {exc}")
    st.stop()

total_nodes = G.number_of_nodes()
total_edges = G.number_of_edges()
high_risk = sum(1 for v in scores.values() if v["score"] >= 4)
c1, c2, c3, c4 = st.columns(4)
c1.metric("Entities", total_nodes)
c2.metric("Relationships", total_edges)
c3.metric("High-risk entities", high_risk)
c4.metric("Events analysed", len(events))

left, right = st.columns([1.7, 1])
with left:
    st.subheader("Threat relationship graph")
    st.plotly_chart(graph_figure(G, scores), use_container_width=True)
    st.caption("Green = lower heuristic score · Amber = medium · Red = elevated")
with right:
    st.subheader("Threat hunting findings")
    rows = []
    for node, result in scores.items():
        rows.append({"Entity": node, "Risk score": result["score"], "Why flagged": "; ".join(result["reasons"])})
    findings = pd.DataFrame(rows).sort_values("Risk score", ascending=False)
    st.dataframe(findings, use_container_width=True, hide_index=True)
    st.subheader("Blast-radius analysis")
    selected = st.selectbox("Select a starting entity", sorted(G.nodes()))
    impacted = blast_radius(G, selected)
    st.metric("Downstream entities reachable", len(impacted))
    if impacted:
        st.write(", ".join(impacted))
    else:
        st.write("No downstream entities found in this event graph.")
    if st.button("Export findings CSV"):
        st.download_button("Download findings", findings.to_csv(index=False).encode("utf-8"),
                           file_name="graphops_findings.csv", mime="text/csv")

with st.expander("View event data"):
    st.dataframe(events, use_container_width=True, hide_index=True)

st.markdown("---")
st.caption("GraphOps AI · Hackathon prototype · Validate all alerts with a security analyst before taking action.")
