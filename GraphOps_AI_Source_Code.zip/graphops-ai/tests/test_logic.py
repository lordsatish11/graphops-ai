import pandas as pd
import networkx as nx

def test_reachability():
    graph = nx.DiGraph()
    graph.add_edges_from([("user1", "host1"), ("host1", "server1")])
    assert set(nx.descendants(graph, "user1")) == {"host1", "server1"}

def test_sample_csv_schema():
    df = pd.read_csv("data/sample_events.csv")
    assert {"source", "target", "event_type", "timestamp", "severity"}.issubset(df.columns)
